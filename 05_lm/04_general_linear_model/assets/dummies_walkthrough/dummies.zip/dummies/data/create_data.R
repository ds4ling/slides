library(tidyverse)

n           <- 40

intercept_a <- 75
covariate   <- rnorm(n, 7, 2)
y_a         <- intercept_a + (covariate * 1.5) + rnorm(n, 0, 2)

intercept_b <- 70
y_b         <- intercept_a + (covariate * 0.75) + rnorm(n, 0, 2)

my_df <- tibble(experience = covariate, children_s = y_a, adults_s = y_b)

write_csv(my_df, "./learner_data.csv")
