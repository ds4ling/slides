library("tidyverse")
library("lme4")



# 1.
#
# Get to know the sleepstudy dataset 
#
# How many rows? Columns? Make a plot. 
#





# 2. 
#
# Fit a complete pooling model (lm)
# Give a rough interpretation of the model summary
#





# 3. 
#
# Fit no pooling models (hint: ?lmList)
# What would be a good visualization to understand individual differences?
#








# 4. 
#
# Fit a partial pooling models
#

# 4a. Fit an intercept only model with by-subject random intercepts
# Describe the summary output, make a visualization if you can think 
# of a good one. 





# 4b. Include a fixed effect for "Days"
# Try to plot this model with individual regression lines for the grouping 
# variable (Subjects) AND the population-level regression line (fixed effect).




# 4c. Include a random slope for "Days"
# Compare model estimates (visually) and do nested model comparisons
# Try to plot this model with individual regression lines for the grouping 
# variable (Subjects) AND the population-level regression line (fixed effect).





# 5. For more practice: 
# glimpse(ChickWeight)
# glimpse(Orange)
